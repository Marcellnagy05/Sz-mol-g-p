var elsoSzam = document.getElementById('elsoSzam').value;

function Osszead(){
    var elsoSzam = document.getElementById('elsoSzam').value;
    var masodikSzam = document.getElementById('masodikSzam').value;
    var Osszeg = parseInt(elsoSzam) + parseInt(masodikSzam);
    document.getElementById('Vegeredmeny').value = Osszeg;
}
function Kivon(){
    var elsoSzam = document.getElementById('elsoSzam').value;
    var masodikSzam = document.getElementById('masodikSzam').value;
    var Kulonbseg = parseInt(elsoSzam) - parseInt(masodikSzam);
    document.getElementById('Vegeredmeny').value = Kulonbseg;
}
function Szoroz(){
    var elsoSzam = document.getElementById('elsoSzam').value;
    var masodikSzam = document.getElementById('masodikSzam').value;
    var Szorzat = parseInt(elsoSzam) * parseInt(masodikSzam);
    document.getElementById('Vegeredmeny').value = Szorzat;
}
function Oszt(){
    var elsoSzam = document.getElementById('elsoSzam').value;
    var masodikSzam = document.getElementById('masodikSzam').value;
    var Hányados = parseInt(elsoSzam) / parseInt(masodikSzam);
    document.getElementById('Vegeredmeny').value = Hányados;
}